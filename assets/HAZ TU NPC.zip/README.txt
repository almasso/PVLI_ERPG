INSTRUCCIONES:

Dibujo:

1. Ve a -> pixilart.com.

2. Click en "New Drawing". 

3. Aparecerá un menú bastante cuqui, en el que, a la izquierda hay un botón
que pone "Open Image". Abre la imagen "example.png" de este .rar desde ese botón.

4. Disfruta dibujando! :)

5. Cuando acabes el dibujo, guarda el .pixil y exporta como .png tu dibujo.

Para los diálogos:

1. Haz un .txt enumerado con los diferentes diálogos que quieras tener.

ejemplo de dialogos.txt:

1- Hola, soy {placeholder}! Un placer conocerte.
2- Me quiero morir :D
3- Me matarías?

FINALMENTE:

Una vez hayas hecho tu(s) dibujo(s) (.png y .pixil) y tu(s) diálogo(s), comprímelos en un
.zip o .rar y mándalo a nuestro correo: manininteractive@gmail.com 
con el asunto: "NPC {Nombre de tu NPC}" y, si quieres, el nombre que figurará en los créditos del juego
en el cuerpo del correo